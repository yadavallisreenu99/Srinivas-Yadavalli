package PageObjects.TestNGDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	
	
	WebDriver driver;
	
	
	@FindBy(id= "username")
	public WebElement userName;
	
	@FindBy(id="password")
	public WebElement userPaswrd;
	
	@FindBy(css="li[id='Inpatient Ward']")
	public WebElement location;
	
	@FindBy(css="input[id='loginButton']")
	public WebElement loginBtn;
	
	@FindBy(xpath="//h4")
	public WebElement hPage;
	
	@FindBy(xpath="//legend[@class='w-auto']")
	public WebElement loginPageloc;
	
	
	
	
	
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public String verifyloginPage()
	{
		return loginPageloc.getText().trim();
	}
	
	public void loginCredentials(String uName, String pwd)
	{
		userName.sendKeys(uName);
		userPaswrd.sendKeys(pwd);
	}
	
	public void clickLoginBtn()
	{
		location.click();
		loginBtn.click();
		
	}
	
	public String homePageLocation()
	{
		return hPage.getText().trim();
	}

}
